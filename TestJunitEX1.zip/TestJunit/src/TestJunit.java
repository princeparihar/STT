import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestJunit {
	
	String message = "Hello World";
	String message1 = "World";
	MessageUtil messageUtil = new MessageUtil(message);
	
	@Test
	public void testPrintMessage() {
		assertEquals(message1,messageUtil.printMessage());
	}
}
